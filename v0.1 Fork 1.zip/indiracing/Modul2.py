
from tkinter import *
class App(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.master = master
        self.init_window()

    def menu(self):
        w = Canvas(root, width=200, height=100)
        w.pack()
        quitButton = Button(text = "quit",command =self.b,  activebackground = "#33B5E5")
        quitButton.place(x=300, y=300)    
        mainloop()
        Misc.lift(w)



    def init_window(self):
        
        self.master.title("GUI")
        root.geometry("1000x800")
        canvas = Canvas(root, width=1000, height=800)
        canvas.pack()
        img = PhotoImage(file="background.png")
        canvas.create_image(500,400, image=img)
        playButton = Button(root, text = "play", command = self.map1, activebackground = "#33B5E5", highlightthickness = 0, bd = 0)
        playButton.place(x=300, y=400)
        imge = PhotoImage(file="play button.png") # make sure to add "/" not "\"
        playButton.config(image=imge)
        root.bind('<Return>', menu)
        root.mainloop()
    def client_exit(self):
        self.map1

    def map1(self):
        board = functions.MyBoard()
        board.load_level()
        board.spawn_players()
        board.show()

def menu(self):
    w = Canvas(root, width=200, height=100)
    w.pack()
    quitButton = Button(text = "quit",  activebackground = "#33B5E5")
    quitButton.place(x=300, y=300)    
    mainloop()
    Misc.lift(w)

def b(self):
        self.menu.destroy()
root = Tk()
app = App(master=root)
app.mainloop()

