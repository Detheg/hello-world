from tkinter import * #imports everything from the tkinter library
root=Tk()

def a(self):
    self.menu.destroy()

def menu(self):


    w = Canvas(root, width=200, height=100)
    w.pack()
    quitButton = Button(text = "quit",command =self.a,  activebackground = "#33B5E5")
    quitButton.place(x=300, y=300)    
    mainloop()
    Misc.lift(w)



root.title("GUI")
root.geometry("1000x800")
canvas = Canvas(root, width=1000, height=800)
canvas.pack()
img = PhotoImage(file="background.png")
canvas.create_image(500,400, image=img)
playButton = Button(root, text = "play", activebackground = "#33B5E5", highlightthickness = 0, bd = 0)
playButton.place(x=300, y=400)
imge = PhotoImage(file="play button.png") # make sure to add "/" not "\"
playButton.config(image=imge)
root.bind('<Return>', menu)

root.mainloop()


