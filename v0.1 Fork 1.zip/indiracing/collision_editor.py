#cd I:\IT\projects\Python\racing_PGA
#python collision_editor.py
import time, pygame
from lib.functions import *

borders = []
class Collision_Board(MyBoard):
    def get_event(self, event, data):
        if event == "mouse_left":
            position = BoardPosition.from_pixel(data)
            borders.append((position.x,position.y))
            self.update_collision_borders()

    def update_collision_borders(self):
        # creates a polygon without closing it (means without connecting last corner to first corner)
        for index in range(1,len(borders)):
            point1 = borders[index-1]
            point2 = borders[index]
            pygame.draw.line(window_surface,(0,0,0),point1,point2,1)
        pygame.display.update()

    def act(self):
        self.update_collision_borders()



    def create_button(x,y,width,height,text,command):
        pass
class Button():
    def __init__(self,x,y,width,height,text,command):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

surface = pygame.image.load('textures/vehicles/motorcycles/green.png')
pygame.display.set_icon(surface)

board = Collision_Board()

window_surface = board._window.window_surface

largeText = pygame.font.Font('freesansbold.ttf',115)
TextSurf, TextRect = text_objects("A bit Racey", largeText)
TextRect.center = (100,100)
window_surface.blit(TextSurf, TextRect)
pygame.display.update()

board.load_level()
board.show()