#!/usr/bin/python3
#cd I:\IT\projects\Python\racing_PGA
#python game.py

import lib.functions as functions
from tkinter import *
import os
import subprocess
import random

class Window(Frame):

    def __init__(self, master = None):
        Frame.__init__(self, master)

        self.master = master

        self.init_window()

    def init_window(self):
        
        self.master.title("GUI")
        root.geometry("1000x800")
        canvas = Canvas(root, width=1000, height=800)
        canvas.pack()
        img = PhotoImage(file="background.png")
        canvas.create_image(500,400, image=img)
        playButton = Button(root, text = "play", command = self.map1, activebackground = "#33B5E5", highlightthickness = 0, bd = 0)
        playButton.place(x=300, y=400)
        imge = PhotoImage(file="play button.png") # make sure to add "/" not "\"
        playButton.config(image=imge)
        root.bind('<Return>', menu)
        root.mainloop()

    def client_exit(self):
        self.map1

    def map1(self):
        board = functions.MyBoard()
        board.load_level()
        board.spawn_players()
        board.show()

def menu(event=None):
    w = Canvas( width=200, height=100)
    w.pack()
    quitButton = Button( text = "play", activebackground = "#33B5E5")
    quitButton.place(x=500, y=300)    
    mainloop()
    Misc.lift(w)


root=Tk()
app = Window(root)



def map1(self):
    board = functions.MyBoard()
    board.load_level()
    board.spawn_players()
    board.show()
