#!/usr/bin/python3


import os,time,math,importlib
from   miniworldmaker import *

import lib.cnfg as cnfg


#----------------------------------------Board----------------------------------------------------#
class MyBoard(PixelBoard):
    def load_level(self):
        self.level = importlib.import_module('levels.'+str(cnfg.level_name)+'.'+str(cnfg.level_name))

        self.columns = self.level.window_width
        self.rows    = self.level.window_height

        self.add_image(self.level.background_directory)
        self.background.tile_size = self.level.background_tile_size

        self.background.is_textured = True
        self.background.is_scaled_to_tile = True
        self.border_colors = [(238, 238, 238, 255),(232, 106, 23, 255),(219, 98, 18, 255), (250, 250, 250, 255)]


        # draws the level textures
        for tile in self.level.tiles:
            self.background.blit(tile[0], position=tile[1], size=tile[2])
    def spawn_players(self):
        for player_index in range(0,cnfg.players):
            if len(cnfg.vehicle_key_binding) - 1 >= player_index:
                key_binding = cnfg.vehicle_key_binding[player_index]
            else:
                key_binding = None


            if len(self.level.player_spawn_transformations) - 1 >= player_index:
                transformation = self.level.player_spawn_transformations[player_index]
            else:
                # Places cars for which no position on the map are defined 15px left to the last car.
                # If no car position is defined, the first car will be placed in the top, left corner.
                spawn_transformations_amount = len(self.level.player_spawn_transformations)
                if spawn_transformations_amount:
                    transformation = self.level.player_spawn_transformations[-1]
                else:
                    transformation = [(0,0,270)]
                offsetX = math.cos(math.radians(transformation[2]))*15
                offsetY = math.sin(math.radians(transformation[2]))*15

                posX    = transformation[0]
                posY    = transformation[1]

                posX   += -offsetX*(player_index - spawn_transformations_amount)
                posY   += -offsetY*(player_index - spawn_transformations_amount)

                transformation = (posX,posY,transformation[2])

            vehicle_color_amount = len(cnfg.vehicle_colors)
            texture_directory    = cnfg.vehicle_colors[player_index % vehicle_color_amount][1]
            texture_directory    = 'textures/vehicles/'+texture_directory


            player          = Player(transformation=transformation, key_binding=key_binding, texture_directory=texture_directory)
            setattr(self,'player'+str(player_index),player)


    # gives the relative cursor postion when left-clicking anywhere
    def get_event(self, event, data):
        print(data)
        if event == "mouse_left":
            position = BoardPosition.from_pixel(data)
            print(position, str(self.get_color_at_board_position(position)))
    """---------copied from miniworldmaker.boards.board.py-------------#
        This overwrites the *update* function of this board to make    #
        changing FPS possible.                                         #
                                                                       #
        If random bugs in the miniworldmaker occur, consider           #
        deactivating or recopying these lines from stated path of      #
        the miniworldmaker module.                                     #
    """                                                                #
    def update(self):                                                  #
        if self.is_running:                                            #
            self._tick = self._tick + 1                                #
            if self._tick > 101 - self.speed:                          #
                self._act_all()                                        #
                self._tick = 0                                         #
        self.frame = self.frame + 1                                    #
        for token in self.tokens:                                      #
            token.update()                                             #
        self.clock.tick(cnfg.fps) #<-- put desired amount of FPS here  #
#----------------------------------------------------------------------#

    






#----------------------------------------Objects----------------------------------------------------#
class stats():
    def __init__(self):

        self. forward_accerlation   = .1
        self.backward_accerlation   = .05
        self.breaking_power         = .2
        self. forward_friction      = .08
        self.backward_friction      = .02

        self. forward_max_speed     = 8
        self.backward_max_speed     = 1


class Player(Actor):

    def __init__(self, transformation, key_binding, texture_directory):
        super().__init__((transformation[0],transformation[1]))
        self.key_binding = key_binding
        self.stats = stats()

        self.add_image(path=texture_directory)
        self.costume.orientation = 0
        self.speed = 0
        self.turn_left(transformation[2])



    def apply_friction(self):
        if self.speed > 0:
            self.speed = max(0,self.speed - self.stats.forward_friction)
        elif self.speed < 0:
            self.speed = min(0,self.speed + self.stats.backward_friction)

    def accelerate(self,direction):
        #*direction* can be "forward" or "backward"
        if direction == 'forward':
            self.speed =  min(self.stats. forward_max_speed,self.speed+self.stats. forward_accerlation)
        elif direction == 'backward' and self.speed <= 0:
            self.speed = -min(self.stats.backward_max_speed,-self.speed+self.stats.backward_accerlation)
        elif direction == 'backward' and self.speed >= 0:
            self.break_()

    def break_(self):
        if self.speed > 0:
            self.speed = max(0,self.speed-self.stats.breaking_power)
        elif self.speed < 0:
            self.speed = min(0,self.speed+self.stats.breaking_power)

    def stop(self):
        self.speed = 0


    def get_event(self, event, data):
        if event == "key_pressed" and self.key_binding:
            if self.key_binding.turn_left in data:
                self.turn_left(3)
            if self.key_binding.turn_right in data:
                self.turn_right(3)
            if self.key_binding.forward in data:
                self.accelerate('forward')
            if self.key_binding.backward in data:
                self.accelerate('backward')


    def act(self):
        self.apply_friction()
        self.move(self.speed)

        # checks for collision
        sensing_colors = self.sensing_colors(distance = 0)
        intersections = [value for value in sensing_colors if value in self.board.border_colors]
        if intersections or not self.sensing_on_board():
            self.move(-self.speed)
            self.stop()