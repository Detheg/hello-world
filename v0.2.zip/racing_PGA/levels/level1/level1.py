window_width  = 600
window_height = 400


background_directory = "textures/grass/land_grass11.png"
background_tile_size = 40



         #     image directory         position        size
         #                                \/            \/
tiles = [#          \/		            X    Y        X    Y
	("textures/roads/road_asphalt03.png",(80,  0),   (80, 80)),
    ("textures/roads/road_asphalt01.png",(80,  80),  (80, 80)),
    ("textures/roads/road_asphalt01.png",(80,  160), (80, 80)),
    ("textures/roads/road_asphalt01.png",(80,  240), (80, 80)),
    ("textures/roads/road_asphalt39.png",(80,  320), (80, 80)),
    ("textures/roads/road_asphalt02.png",(160, 320), (80, 80)),
    ("textures/roads/road_asphalt02.png",(240, 320), (80, 80)),
    ("textures/roads/road_asphalt41.png",(320, 320), (80, 80)),
    ("textures/roads/road_asphalt01.png",(320, 240), (80, 80)),
    ("textures/roads/road_asphalt01.png",(320, 160), (80, 80)),
    ("textures/roads/road_asphalt01.png",(320, 80),  (80, 80)),
    ("textures/roads/road_asphalt05.png",(320, 00),  (80, 80)),
    ("textures/roads/road_asphalt02.png",(240, 00),  (80, 80)),
    ("textures/roads/road_asphalt02.png",(160, 00),  (80, 80)),
]


player_spawn_transformations = [
#     X   Y  rotation
    (100, 80,  180),
    (125, 80,  180),
    (100,110,  180),
    (125,110,  180),
    (100,140,  180),
    (125,140,  180),
    (100,170,  270),
]