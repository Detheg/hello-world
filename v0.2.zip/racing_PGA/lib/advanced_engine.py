#!/usr/bin/python3
import math, pygame
from   miniworldmaker import *
from   miniworldmaker.tools.image_renderers import ImageRenderer
from   miniworldmaker.boards.board_position import BoardPosition
from   typing import Union

# indents a multi-line string
def indent(text, amount, ch=' '):
    padding = amount * ch
    return ''.join(padding+line for line in text.splitlines(True))
# dyes a text
def dye(text, color: Union[str,int]):
    color_code = 0
    if type(color) == str:
        color = color.lower()
        if   color == 'black':
            color_code = 30
        elif color == 'red':
            color_code = 31
        elif color == 'green':
            color_code = 32
        elif color == 'yellow':
            color_code = 33
        elif color == 'blue':
            color_code = 34
        elif color == 'purple':
            color_code = 35
        elif color == 'cyan':
            color_code = 36
        elif color == 'white':
            color_code = 37
    else:
        color_code = color

    return '\033[1;%s;40m' % color_code + text + '\033[1;37;40m'

#----------------------------------------Collision----------------------------------------------------#
class Point():
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __str__(self):
        return 'Point('+str(self.x)+'/'+str(self.y)+')'
    def __repr__(self):
        return 'Point('+str(self.x)+'/'+str(self.y)+')'

    def get_angle(self): # returns the angle between the negative y-axis and the line from the origin to this point(x/y)
        return math.degrees(math.atan2(self.y,self.x)) - 90

    def get_distance(self, point=None): # returns the distance to another point or the origin
        if point == None:
            point = Point(0,0)
        return math.hypot(self.x - point.x,self.y - point.y)

    def rotate_right(self,degrees,pivot=None): # rotates the point clockwise around a pivot or the origin (clockwise when assumed (0/0) is the top-left corner on screen and not the bottom-left)
        if pivot==None:
            pivot = Point(0,0)
        self.x -= pivot.x
        self.y -= pivot.y

        radius = self.get_distance()
        angle  = self.get_angle() + degrees


        self.x = math.cos(math.radians(angle + 90))*radius
        self.y = math.sin(math.radians(angle + 90))*radius

        self.x += pivot.x
        self.y += pivot.y
        return self

    def rotate_left(self,degrees,pivot=None): # rotates the point counter-clockwise around a pivot or the origin
        self.rotate_right(-degrees,pivot)

    def copy(self):
        return Point(self.x,self.y)
    def to_tuple(self):
        return (self.x,self.y)
class Intersection():
    def __init__(self, position, angle):
        self.position = position
        self.angle    = angle

    def __str__(self):
        return 'Intersection point at ('+str(self.position.x)+'/'+str(self.position.y)+') with alpha='+str(self.angle)
    def __repr__(self):
        return 'Intersection point at ('+str(self.position.x)+'/'+str(self.position[1])+') with alpha='+str(self.angle)
class Linear_Function():
    def __init__(self, m, n):
        self.m,self.n = m,n

    def f(self,x):
        return self.m*x+self.n
class Collision_Line():
    def __init__(self, point1,point2,open_angle=(0,0),command=None,parameters=None):
        self.point1     = point1
        self.point2     = point2
        self.open_angle = open_angle # the angle from which to which objects can pass through this line
        self.command    = command # the command executed when something hits this line
        self.parameters = parameters # the parameters passed to the command when it's executed

        self.line_object = None # pygame object


    last_attribute_name = 'parameters'

    def __str__(self):
        return 'Collision_Line\n    point1     = %s\n    point2     = %s\n    open_angle = %s\n    command    = %s\n    parameters = %s\n' % (str(self.point1),str(self.point2),str(self.open_angle),str(self.command),str(self.parameters))
    def __repr__(self):
        return 'Collision_Line\n    point1     = %s\n    point2     = %s\n    open_angle = %s\n    command    = %s\n    parameters = %s\n' % (str(self.point1),str(self.point2),str(self.open_angle),str(self.command),str(self.parameters))

    def is_vertical(self):
        return self.point1.x == self.point2.x

    def to_linear_function(self):
        if not self.is_vertical():
            m = (self.point1.y - self.point2.y)/(self.point1.x - self.point2.x)
            n = self.point1.y - m*self.point1.x

            return Linear_Function(m,n)
        else:
            raise ValueError("Can't convert vertical line into function.")
        
    def is_parallel_to(self,collision_line2):
        if self.is_vertical() or collision_line2.is_vertical():
            if self.is_vertical() and collision_line2.is_vertical():
                return True
            else:
                return False
        else:
            func1 = self.to_linear_function()
            func2 = collision_line2.to_linear_function()
            return func1.m == func2.m

    def get_intersection(self,collision_line2):
        # checks if they intersect at all
        if self.is_parallel_to(collision_line2):
            if self.is_vertical():
                if self.point1.x == collision_line2.point1.x:
                    return Intersection(self.point1,0)
                else:
                    return False
            else: 
                func1 = self.to_linear_function()
                func2 = collision_line2.to_linear_function()

                if func1.n == func2.n:
                    return Intersection(self.point1,0)
                else:
                    return False

        # calculates the intersection point and angle (***angle still experimental***)
        intersection = Intersection(Point(0,0),0)
        if self.is_vertical():
            func2 = collision_line2.to_linear_function()
            x     = self.point1.x
            y     = func2.f(x)
            intersection.position = Point(x,y)
            intersection.angle    = math.degrees(math.atan(func2.m)) - 90

        elif collision_line2.is_vertical():
            func1 = self.to_linear_function()
            x     = collision_line2.point1.x
            y     = func1.f(x)
            intersection.position = Point(x,y)
            intersection.angle    = 90 - math.degrees(math.atan(func1.m))

        else:
            func1 = self.to_linear_function()
            func2 = collision_line2.to_linear_function()
            x     = (func2.n-func1.n)/(func1.m-func2.m)
            y     = func1.f(x)
            intersection.position = Point(x,y)
            intersection.angle    = math.degrees(math.atan(func2.m)-math.atan(func1.m))

        # checks if the intersection point within both definition ranges
        line1_min_x = min(self.point1.x,self.point2.x)
        line1_max_x = max(self.point1.x,self.point2.x)

        line2_min_x = min(collision_line2.point1.x,collision_line2.point2.x)
        line2_max_x = max(collision_line2.point1.x,collision_line2.point2.x)

        line1_min_y = min(self.point1.y,self.point2.y)
        line1_max_y = max(self.point1.y,self.point2.y)

        line2_min_y = min(collision_line2.point1.y,collision_line2.point2.y)
        line2_max_y = max(collision_line2.point1.y,collision_line2.point2.y)


        if line1_min_x <= x <= line1_max_x and line2_min_x <= x <= line2_max_x and line1_min_y <= y <= line1_max_y and line2_min_y <= y <= line2_max_y:
            return intersection
        else:
            return False


    def draw(self,surface):
        self.line_object = pygame.draw.line(surface,(0,0,0),self.point1.to_tuple(),self.point2.to_tuple(),1)

    def remove(self,surface): # draws a white line above the old line because there is no real removal function in pygame exept for sprites
        pygame.draw.line(surface,(255,255,255),self.point1.to_tuple(),self.point2.to_tuple(),1)
        pygame.display.update()
        self.line_object = None




#--------------------------------------Engine advances-----------------------------------------------------------------#
class AdvancedActor(Actor):
    """
        advances the Actor class from miniworldmaker with:
        * line-tracing
        * polygon-tracing
        * a method to return the position of the Actor's center on the Board instead of its top-left corner's position
        * a method to convert relative Points and angles on the Actor to Board positions/directions
        * a possibility to change the actors position by less than a pixel
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        position            = BoardPosition(
                                self.position.x,
                                self.position.y,
                              )
        self.exact_position = self.position

    """---------copied from miniworldmaker.boards.board.py----------------------------------#
        This overwrites the *move* method                                                   #
        and makes it possible to move the Actor by less than a pixel.                       #
    """                                                                                     #
    def move(self, distance: float = 0):                                                    #
        if distance == 0:                                                                   #
            distance = self.speed                                                           #
                                                                                            #
        delta_x =  math.sin(math.radians(self.direction))*distance                          #
        delta_y = -math.cos(math.radians(self.direction))*distance                          #
                                                                                            #
        self.exact_position.x += delta_x                                                    #
        self.exact_position.y += delta_y                                                    # 
        copied_position = BoardPosition(                                                    #
                            self.exact_position.x,                                          #
                            self.exact_position.y,                                          #
                          )                                                                 #
        self.position = copied_position                                                     #
        self.last_direction=self.direction                                                  #
        return self                                                                         #
    #---------------------------------------------------------------------------------------#


    @property
    def info_overlay(self):
        return self.costume.info_overlay
    @info_overlay.setter
    def info_overlay(self,value):
        # displays the boundries of the sprite when its rotated
        self.costume.info_overlay = value

    def get_vehicle_size(self):
        # estimates the downscaled size of the sprite-image
        image           = self.costume.images_list[0]
        ratio           = image.get_width()/image.get_height()
        width           = self.size[0]*ratio
        height          = self.size[1]
        return (width,height)
    def get_sprite_size(self):
        # estimates the boundry size of the image when its rotated
        vehicle_size = self.get_vehicle_size()

        alpha   = math.radians((-self.direction + 180) % 180)

        if alpha >= math.radians(90):
            alpha -= math.radians(90)
            height = (math.sin(alpha)*vehicle_size[1] + math.cos(alpha)*vehicle_size[0])
            width  = (math.sin(alpha)*vehicle_size[0] + math.cos(alpha)*vehicle_size[1])
        else:
            width  = (math.sin(alpha)*vehicle_size[1] + math.cos(alpha)*vehicle_size[0])
            height = (math.sin(alpha)*vehicle_size[0] + math.cos(alpha)*vehicle_size[1])

        return (width,height)
    def get_relative_center_position(self):
        size    = self.get_sprite_size()
        offsetX = size[0]/2
        offsetY = size[1]/2
        
        return Point(offsetX,offsetY)

    def get_center_position(self):
        x = self.position.x
        y = self.position.y

        offset = self.get_relative_center_position()

        x += offset.x
        y += offset.y
        return Point(x,y)
    def to_absolute_position(self, offset: Point): # converts a relative Point on the Actor to a Board position
        point = offset.copy()
        point.rotate_right(self.direction)

        player_pos = self.get_center_position()
        point.x += player_pos.x
        point.y += player_pos.y

        return point
    def to_absolute_rotation(self, rotation: float):
        return self.direction + rotation

    def trace_line(self,distance,offset=Point(0,0),angle=0,draw_line=False): # draws a line forward and checks if it intersects with a border
        """if distance >= 0: # the length of the trace line should be at least 2 pixel
            distance = max(2, distance)
        else:
            distance = min(-2,distance)"""

        angle  = self.to_absolute_rotation(angle)
        offset = self.to_absolute_position(offset)

        start = Point(0,0)
        end   = Point(0,-distance)
        end.rotate_right(angle)

        start.x += offset.x
        start.y += offset.y
        end.x   += offset.x
        end.y   += offset.y

        line     = Collision_Line(start,end)
        player_pos = self.get_center_position()

        if draw_line:
            line.draw(self.board._window.window_surface)
            pygame.display.update()

        nearest          = None
        nearest_distance = None
        for collision_line in self.board.collision_lines:
            intersection = line.get_intersection(collision_line)
            if intersection:
                distance = player_pos.get_distance(intersection.position)
                if distance != 0: # <-- keeps the player from getting stuck when the tracer is being used for collision detection
                    if nearest != None:
                        if distance < nearest_distance:
                            nearest          = intersection
                            nearest_distance = distance
                    else:
                        nearest         = intersection
                        nearest_distance = distance
        
        if nearest:
            return nearest
        else:
            return False
    def trace_polygon(self,points: list,offset=Point(0,0),rotation=0,draw_lines=False): # traces multiple lines to simulate the tracing of a polygon
        intersections = []
        for index in range(len(points)):
            start = points[index].copy()

            if index + 1 != len(points):
                end = points[index+1]
            else:
                end = points[0]

            distance = start.get_distance(end)
            diff     = Point(start.x - end.x, start.y - end.y)
            angle    = diff.get_angle()

            start.x += offset.x
            start.y += offset.y
            angle   += rotation

            start.rotate_right(rotation, points[0])

            intersection = self.trace_line(distance,start,angle,draw_line=draw_lines)
            intersections.append(intersection)

        return intersections
    
    def check_for_collision(self,delta_forward, delta_direction, draw_hitbox=False):
        """ the length of the drawn hitbox should be a few pixels larger than the distance covered
            to make sure the collision detection really works
        """
        if delta_forward >= 0:
            delta_forward += 1
        else:
            delta_forward -= 1


        width,height = self.get_vehicle_size()

        if not delta_forward and not delta_direction:
            return False

        if delta_forward >= 0:
            point1 = Point(-width/2,-height/2)
            point2 = Point(-width/2,-height/2 - delta_forward)
            point3 = Point( width/2,-height/2 - delta_forward) 
            point4 = Point( width/2,-height/2)
        else:
            point1 = Point(-width/2, height/2)
            point2 = Point(-width/2, height/2 - delta_forward)
            point3 = Point( width/2, height/2 - delta_forward)
            point4 = Point( width/2, height/2)

        if delta_direction > 0:
            point3.rotate_right(delta_direction)
            point4.rotate_right(delta_direction)
        elif delta_direction < 0:
            point1.rotate_right(delta_direction)
            point2.rotate_right(delta_direction)

        intersections = self.trace_polygon([point1,point2,point3,point4], rotation=0 ,draw_lines=draw_hitbox)

        for intersection in intersections:
            if intersection:
                return True
        else:
            return False

class AdvancedBoard(PixelBoard):
    """
        Advances the PixelBoard class from miniworldmaker with:
        *a setting to change the amount of fps, by overwriting the *update* method
    """
    def __init__(self, fps=60):
        super().__init__()
        self.fps = fps
        self.current_framerate = fps # the current framerate
        
    """---------copied from miniworldmaker.boards.board.py-------------#
        This overwrites the *update* method of this board to make      #
        changing FPS possible and to save the current amount of fps.   #
                                                                       #
        If random bugs in the miniworldmaker occur, consider           #
        deactivating or recopying these lines from stated path of      #
        the miniworldmaker module.                                     #
    """                                                                #
    def update(self):                                                  #
        if self.is_running:                                            #
            self._tick = self._tick + 1                                #
            if self._tick > 101 - self.speed:                          #
                self._act_all()                                        #
                self._tick = 0                                         #
        self.frame = self.frame + 1                                    #
        for token in self.tokens:                                      #
            token.update()                                             #
        self.clock.tick(self.fps) #<-- put desired amount of FPS here  #
        #                                                              #
        #                                                              #
        self.current_framerate = self.clock.get_fps()                  #
    #------------------------------------------------------------------#