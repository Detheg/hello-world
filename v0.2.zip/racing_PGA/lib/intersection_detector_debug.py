from advanced_engine import *
import turtle,sys

# insert test data here
p1 = Point(100,500)
p2 = Point(400,700)

p3 = Point(400,500)
p4 = Point(300,700)

p5 = Point(400,100)
p6 = Point(300,300)

p7 = Point(300,100)
p8 = Point(300,1000)

p9 =  Point(000,600)
p10 = Point(500,600)

p11 = Point(472, 116)
p12 = Point(542, 116)

lines = [
    (p1, p2, p3, p4),
    (p3, p4, p1, p2),
    (p1, p2, p5, p6),
    (p3, p4, p5, p6),
    (p1, p2, p7, p8),
    (p7, p8, p1, p2),
    (p1, p2, p9, p10),
    (p9, p10, p1, p2),
    (p7, p8, p9, p10),
    (p9, p10, p7, p8),
]


# executes the test
print('INTERSECTION DETECTOR TEST')

for p1,p2,p3,p4 in lines:
    turtle1 = turtle.Turtle()

    line1 = Collision_Line(p1,p2)
    line2 = Collision_Line(p3,p4)

    do_intersect = line1.get_intersection(line2)

    print('Intersection detected?',bool(do_intersect))

    turtle.penup()
    turtle.setpos(p1.to_tuple())
    turtle.pendown()
    turtle.goto(p2.to_tuple())
    turtle.penup()
    turtle.setpos(p3.to_tuple())
    turtle.pendown()
    turtle.goto(p4.to_tuple())

    if input('CONFIRM'):
        sys.exit(1)
    turtle.clear()

print('DONE')