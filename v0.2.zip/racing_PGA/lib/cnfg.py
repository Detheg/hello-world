#!/usr/bin/python3

#----------------------------------------GAME SETTINGS--------------------------------------------------#
level_name = 'level2'
players    = 3
px_in_m    = 12





#----------------------------------------GRAPHICAL SETTINGS---------------------------------------------#
fps = 60
vehicle_colors = [
#     color    directory relative to "/textures/vehicles"
#      \/              \/
    ('green' ,'motorcycles/green.png' ),
    ('blue'  ,'motorcycles/blue.png'  ),
    ('black' ,'motorcycles/black.png' ),
    ('orange','motorcycles/orange.png'),
    ('yellow','motorcycles/yellow.png'),
]





#----------------------------------------KEY BINDING----------------------------------------------------#
class Vehicle_key_binding():
    def __init__(self, forward, turn_left, backward, turn_right):
        self.forward    =forward
        self.backward   =backward
        self.turn_left  =turn_left
        self.turn_right =turn_right
    def __str__(self):
        return str(self.forward)+' '+str(self.turn_left)+' '+str(self.backward)+' '+str(self.turn_right)

vehicle_key_binding=[
    Vehicle_key_binding('W' ,'A'   ,'S'   ,'D'    ),
    Vehicle_key_binding('UP','LEFT','DOWN','RIGHT'),
]



#----------------------------------------DEBUG-----------------------------------------------------------#
enable_debug_mode    = True
#---debug mode settings---#
print_screen_info    = True
print_player_info    = True
printing_interval    = 1000

show_sprite_boundies = False
show_hitboxes        = False