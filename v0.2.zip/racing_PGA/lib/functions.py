#!/usr/bin/python3


import os,time,math,importlib,json,pygame
from   miniworldmaker import *

import lib.cnfg as cnfg
from   lib.advanced_engine import *

last_log = time.time()
#----------------------------------------Board----------------------------------------------------#
class MyBoard(AdvancedBoard):
    collision_lines = []

    def __init__(self):
        super().__init__()
        self.fps = cnfg.fps

    def load_level(self):
        # imports the level itself and applies its settings to the board
        self.level = importlib.import_module('levels.'+str(cnfg.level_name)+'.'+str(cnfg.level_name))

        self.columns = self.level.window_width
        self.rows    = self.level.window_height

        self.add_image(self.level.background_directory)
        self.background.tile_size = self.level.background_tile_size

        self.background.is_textured = True
        self.background.is_scaled_to_tile = True


        # draws the level textures
        for tile in self.level.tiles:
            self.background.blit(tile[0], position=tile[1], size=tile[2])

        # loads the collision lines
        file = open('levels/'+str(cnfg.level_name)+'/collision_lines.txt')
        data = file.read()

        new_collision_line = Collision_Line(Point(0,0),Point(0,0))
        for text_line in data.split('\n'):
            if text_line != 'Collision_Line':
                attribute = text_line[:15].strip()
                value     = text_line[16:].strip()
                value     = value.replace('/',',')

                if attribute in ['point1','point2','open_angle','parameters','command']:
                    setattr(new_collision_line,attribute,eval(value))

                if attribute == Collision_Line.last_attribute_name:
                    self.collision_lines.append(new_collision_line)
                    new_collision_line = Collision_Line(Point(0,0),Point(0,0))
                    

    def spawn_players(self):
        for player_index in range(0,cnfg.players):
            if len(cnfg.vehicle_key_binding) - 1 >= player_index:
                key_binding = cnfg.vehicle_key_binding[player_index]
            else:
                key_binding = None


            if len(self.level.player_spawn_transformations) - 1 >= player_index:
                transformation = self.level.player_spawn_transformations[player_index]
            else:
                # Places cars without defined map position 15px left to the last car.
                # If no car position is defined, the first car will be placed in the top, left corner.
                spawn_transformations_amount = len(self.level.player_spawn_transformations)
                if spawn_transformations_amount:
                    transformation = self.level.player_spawn_transformations[-1]
                else:
                    transformation = [(0,0,270)]
                offsetX = math.cos(math.radians(transformation[2]))*15
                offsetY = math.sin(math.radians(transformation[2]))*15

                posX    = transformation[0]
                posY    = transformation[1]

                posX   += -offsetX*(player_index - spawn_transformations_amount)
                posY   += -offsetY*(player_index - spawn_transformations_amount)

                transformation = (posX,posY,transformation[2])

            vehicle_color_amount = len(cnfg.vehicle_colors)
            texture_directory    = cnfg.vehicle_colors[player_index % vehicle_color_amount][1]
            texture_directory    = 'textures/vehicles/'+texture_directory


            player          = Player(transformation=transformation, key_binding=key_binding, texture_directory=texture_directory)
            setattr(self,'player'+str(player_index),player)


    # gives the relative cursor postion when left-clicking anywhere
    def get_event(self, event, data):
        if event == "mouse_left":
            position = BoardPosition.from_pixel(data)
            print(position, str(self.get_color_at_board_position(position)))

    def act(self):

        # checks if the debug informations have to be updated this frame
        if cnfg.enable_debug_mode and (time.time() - last_log >= cnfg.printing_interval/1000):
            self.print_debug_informations()


    def print_debug_informations(self):
        global last_log
        log = dye('[DEBUG]:\n', 'red')
        if cnfg.print_screen_info:
            log += dye(' *SCREEN:\n','green')
            log +=     '   '+str(self.columns)+'x'+str(self.rows)+'px\n'
            log +=     '   @'+str(int(self.current_framerate))+'/'+str(int(cnfg.fps))+'fps\n'

        if cnfg.print_player_info:
            player_amount = cnfg.players
            log += dye(' *Players: %s\n' % str(cnfg.players),'green')

            for token in self.tokens:
                if token.__class__.__name__ == 'Player':
                    log += indent(str(token),3)
                    log += '\n'


        print(log)
        last_log = time.time()

    






#----------------------------------------Objects----------------------------------------------------#
class stats():
    def __init__(self):
        # all speeds and accelerations in px/s or px/s²
        self. forward_accerlation   = 6*60
        self.backward_accerlation   = 3*60
        self.breaking_power         = 8*60
        self. forward_friction      = 4.8*60
        self.backward_friction      = 1.2*60

        self.max_forward_speed      = 480
        self.max_backward_speed     = 120

        self.max_gForce             = 10
        self.max_steering_angle     = 30
        self.wheel_distance         = 0.8     # distance from front to backwheels relative to the cars length

        
class Player(AdvancedActor):

    def __init__(self, transformation, key_binding, texture_directory):
        super().__init__(position=(transformation[0],transformation[1]))

        self.key_binding = key_binding
        self.stats = stats()

        self.add_image(path=texture_directory)
        self.costume.orientation = 0
        self.turn_left(transformation[2])

        self.speed = 0
        self.steering_angle = 0

        self.info_overlay = cnfg.show_sprite_boundies
        #self.info_overlay = True

    def __str__(self):
        string  = 'Player:\n'
        string += ' X:          '+'{:.2f}px\n'.format(self.exact_position.x)
        string += ' Y:          '+'{:.2f}px\n'.format(self.exact_position.y)
        string += ' direction:  '+'{:.2f} degrees\n'.format(self.direction)
        string += ' KeyBinding: '+str(self.key_binding)
        return string


    def get_max_possible_steering_angle(self):
        g      = 9.81
        G      = self.stats.max_gForce
        length = self.stats.wheel_distance*self.get_vehicle_size()[1]/cnfg.px_in_m
        speed  = self.speed/cnfg.px_in_m

        radius = (speed**2)/G/g

        if radius > length:
            alpha = math.degrees(math.asin(length/radius))
        else:
            alpha = self.stats.max_steering_angle

        alpha = min(alpha, self.stats.max_steering_angle)

        return alpha

    def act(self):
        # checks for collision

        #print(self.get_max_possible_steering_angle())
        
        #self.trace_polygon([Point(0,0),Point(-10,0),Point(-10,-10),Point(0,-10)], rotation=0, draw_lines=True)

        vehicle_length   = self.get_vehicle_size()[1]
        delta_direction  = self.steering_angle
        delta_direction *= self.px_p_s_to_px_p_frame(self.speed)
        delta_direction /= self.stats.wheel_distance
        delta_direction /= vehicle_length

        delta_forward = self.px_p_s_to_px_p_frame(self.speed)

        collision = self.check_for_collision(delta_forward, delta_direction, draw_hitbox=cnfg.show_hitboxes and cnfg.enable_debug_mode)

        if collision:
            self.stop()
        else:

            self.turn_right(delta_direction)

            self.move(delta_forward)

            self.apply_friction()

    def px_p_s_to_px_p_frame(self,value):
        if self.board.current_framerate:
            return value/self.board.current_framerate
        else:
            return value/self.board.fps

    def apply_friction(self):
        if self.speed > 0:
            self.speed = max(0,self.speed - self.px_p_s_to_px_p_frame(self.stats.forward_friction))
        elif self.speed < 0:
            self.speed = min(0,self.speed + self.px_p_s_to_px_p_frame(self.stats.backward_friction))

    def accelerate(self,direction):
        #*direction* can be "forward" or "backward"
        if direction == 'forward':
            self.speed =  min(self.stats. max_forward_speed,self.speed+self.px_p_s_to_px_p_frame(self.stats. forward_accerlation))
        elif direction == 'backward' and self.speed <= 0:
            self.speed = -min(self.stats.max_backward_speed,-self.speed+self.px_p_s_to_px_p_frame(self.stats.backward_accerlation))
        elif direction == 'backward' and self.speed >= 0:
            self.break_()

    def break_(self):
        if self.speed > 0:
            self.speed = max(0,self.speed-self.px_p_s_to_px_p_frame(self.stats.breaking_power))
        elif self.speed < 0:
            self.speed = min(0,self.speed+self.px_p_s_to_px_p_frame(self.stats.breaking_power))

    def stop(self):
        self.speed = 0


    def get_event(self, event, data):
        if self.key_binding:
            if event == 'key_pressed':
                # steering
                if self.key_binding.turn_left in data:
                    self.steering_angle = -self.get_max_possible_steering_angle()
                if self.key_binding.turn_right in data:
                    self.steering_angle = self.get_max_possible_steering_angle()

                # accellerating
                if self.key_binding.forward in data:
                    self.accelerate('forward')
                if self.key_binding.backward in data:
                    self.accelerate('backward')
            else:
                data = []

            if not ((self.key_binding.turn_left in data) or (self.key_binding.turn_right in data)):
                self.steering_angle = 0