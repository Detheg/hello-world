#!/usr/bin/python3

#----------------------------------------GAME SETTINGS--------------------------------------------------#
level_name = 'level2'
players    = 2





#----------------------------------------GRAPHICAL SETTINGS---------------------------------------------#
fps = 60
vehicle_colors = [
#     color    directory relative to "/textures/vehicles"
#      \/              \/
    ('green' ,'motorcycles/green.png' ),
    ('blue'  ,'motorcycles/blue.png'  ),
    ('black' ,'motorcycles/black.png' ),
    ('orange','motorcycles/orange.png'),
    ('yellow','motorcycles/yellow.png'),
]





#----------------------------------------KEY BINDING----------------------------------------------------#
class vehicle_key_binding_constructor():
    def __init__(self, forward, turn_left, backward, turn_right):
        self.forward    =forward
        self.backward   =backward
        self.turn_left  =turn_left
        self.turn_right =turn_right

vehicle_key_binding=[
    vehicle_key_binding_constructor('W' ,'A'   ,'S'   ,'D'    ),
    vehicle_key_binding_constructor('UP','LEFT','DOWN','RIGHT'),
]