#!/usr/bin/python3


import os,time,math,importlib,json,pygame
from   miniworldmaker import *

import lib.cnfg as cnfg


#----------------------------------------Collision----------------------------------------------------#
class Collision_Line():
    def __init__(self, point1,point2,open_angle=(0,0),command=None,parameters=None):
        self.point1     = point1
        self.point2     = point2
        self.open_angle = open_angle # the angle from which to which objects can pass through this line
        self.command    = command # the command executed when something hits this line
        self.parameters = parameters # the parameters passed to the command when it's executed

        self.line_object = None # pygame object


    last_attribute_name = 'parameters'

    def __str__(self):
        return 'Collision_Line\n    point1     = %s\n    point2     = %s\n    open_angle = %s\n    command    = %s\n    parameters = %s\n' % (str(self.point1),str(self.point2),str(self.open_angle),str(self.command),str(self.parameters))
    def __repr__(self):
        return 'Collision_Line\n    point1     = %s\n    point2     = %s\n    open_angle = %s\n    command    = %s\n    parameters = %s\n' % (str(self.point1),str(self.point2),str(self.open_angle),str(self.command),str(self.parameters))

    def is_vertical(self):
        return self.point1[0] == self.point2[0]

    def to_linear_function(self):
        if not self.is_vertical():
            m = (self.point1[1] - self.point2[1])/(self.point1[0] - self.point2[0])
            n = self.point1[1] - m*self.point1[0]

            return Linear_Function(m,n)
        else:
            raise ValueError("Can't convert vertical line into function.")
        
    def is_parallel_to(self,collision_line2):
        if self.is_vertical() or collision_line2.is_vertical():
            if self.is_vertical() and collision_line2.is_vertical():
                return True
            else:
                return False
        else:
            func1 = self.to_linear_function()
            func2 = collision_line2.to_linear_function()
            return func1.m == func2.m

    def get_intersection(self,collision_line2):
        #if self.point1 == self.point2 or collision_line2.point1 == collision_line2.point2:
        #    return False # one of the lines has no length thus no intersection

        # checks if they intersect at all
        if self.is_parallel_to(collision_line2):
            if self.is_vertical():
                if self.point1[0] == collision_line2.point1[0]:
                    return Intersection(self.point1,0)
                else:
                    return False
            else: 
                func1 = self.to_linear_function()
                func2 = collision_line2.to_linear_function()

                if func1.n == func2.n:
                    return Intersection(self.point1,0)
                else:
                    return False

        # calculates the intersection point and angle
        intersection = Intersection((0,0),0)
        if self.is_vertical():
            func2 = collision_line2.to_linear_function()
            x     = self.point1[0]
            y     = func2.f(x)
            intersection.position = (x,y)
            intersection.angle    = math.degrees(math.atan(func2.m)) - 90

        elif collision_line2.is_vertical():
            func1 = self.to_linear_function()
            x     = collision_line2.point1[0]
            y     = func1.f(x)
            intersection.position = (x,y)
            intersection.angle    = 90 - math.degrees(math.atan(func1.m))

        else:
            func1 = self.to_linear_function()
            func2 = collision_line2.to_linear_function()
            x     = (func2.n-func1.n)/(func1.m-func2.m)
            y     = func1.f(x)
            intersection.position = (x,y)
            intersection.angle    = math.degrees(math.atan(func2.m)-math.atan(func1.m))

        # checks if the intersection point within both definition ranges
        line1_min_x = min(self.point1[0],self.point2[0])
        line1_max_x = max(self.point1[0],self.point2[0])

        line2_min_x = min(collision_line2.point1[0],collision_line2.point2[0])
        line2_max_x = max(collision_line2.point1[0],collision_line2.point2[0])

        line1_min_y = min(self.point1[1],self.point2[1])
        line1_max_y = max(self.point1[1],self.point2[1])

        line2_min_y = min(collision_line2.point1[1],collision_line2.point2[1])
        line2_max_y = max(collision_line2.point1[1],collision_line2.point2[1])


        if line1_min_x <= x <= line1_max_x and line2_min_x <= x <= line2_max_x and line1_min_y <= y <= line1_max_y and line2_min_y <= y <= line2_max_y:
            return intersection
        else:
            return False

    def draw(self,surface):
        self.line_object = pygame.draw.line(surface,(0,0,0),self.point1,self.point2,1)

    def remove(self,surface): # draws a white line above the old line because there is no real removal function in pygame exept for sprites
        pygame.draw.line(surface,(255,255,255),self.point1,self.point2,1)
        pygame.display.update()
        self.line_object = None

class Intersection():
    def __init__(self, position, angle):
        self.position = position
        self.angle    = angle

    def __str__(self):
        return 'Intersection point at ('+str(self.position[0])+'/'+str(self.position[1])+') with alpha='+str(self.angle)
    def __repr__(self):
        return 'Intersection point at ('+str(self.position[0])+'/'+str(self.position[1])+') with alpha='+str(self.angle)
class Linear_Function():
    def __init__(self, m, n):
        self.m,self.n = m,n

    def f(self,x):
        return self.m*x+self.n
        



#----------------------------------------Board----------------------------------------------------#
class MyBoard(PixelBoard):
    collision_lines = []

    def load_level(self):
        # imports the level itself and applies its settings to the board
        self.level = importlib.import_module('levels.'+str(cnfg.level_name)+'.'+str(cnfg.level_name))

        self.columns = self.level.window_width
        self.rows    = self.level.window_height

        self.add_image(self.level.background_directory)
        self.background.tile_size = self.level.background_tile_size

        self.background.is_textured = True
        self.background.is_scaled_to_tile = True
        self.border_colors = [(238, 238, 238, 255),(232, 106, 23, 255),(219, 98, 18, 255), (250, 250, 250, 255)]


        # draws the level textures
        for tile in self.level.tiles:
            self.background.blit(tile[0], position=tile[1], size=tile[2])

        # loads the collision lines
        file = open('levels/'+str(cnfg.level_name)+'/collision_lines.txt')
        data = file.read()

        new_collision_line = Collision_Line((0,0),(0,0))
        for text_line in data.split('\n'):
            if text_line != 'Collision_Line':
                attribute = text_line[:15].strip()
                value     = text_line[16:].strip()
                

                if attribute in ['point1','point2','open_angle','parameters','command']:
                    setattr(new_collision_line,attribute,eval(value))

                if attribute == Collision_Line.last_attribute_name:
                    self.collision_lines.append(new_collision_line)
                    new_collision_line = Collision_Line((0,0),(0,0))
                    

    def spawn_players(self):
        for player_index in range(0,cnfg.players):
            if len(cnfg.vehicle_key_binding) - 1 >= player_index:
                key_binding = cnfg.vehicle_key_binding[player_index]
            else:
                key_binding = None


            if len(self.level.player_spawn_transformations) - 1 >= player_index:
                transformation = self.level.player_spawn_transformations[player_index]
            else:
                # Places cars for which no position on the map are defined 15px left to the last car.
                # If no car position is defined, the first car will be placed in the top, left corner.
                spawn_transformations_amount = len(self.level.player_spawn_transformations)
                if spawn_transformations_amount:
                    transformation = self.level.player_spawn_transformations[-1]
                else:
                    transformation = [(0,0,270)]
                offsetX = math.cos(math.radians(transformation[2]))*15
                offsetY = math.sin(math.radians(transformation[2]))*15

                posX    = transformation[0]
                posY    = transformation[1]

                posX   += -offsetX*(player_index - spawn_transformations_amount)
                posY   += -offsetY*(player_index - spawn_transformations_amount)

                transformation = (posX,posY,transformation[2])

            vehicle_color_amount = len(cnfg.vehicle_colors)
            texture_directory    = cnfg.vehicle_colors[player_index % vehicle_color_amount][1]
            texture_directory    = 'textures/vehicles/'+texture_directory


            player          = Player(transformation=transformation, key_binding=key_binding, texture_directory=texture_directory)
            setattr(self,'player'+str(player_index),player)


    # gives the relative cursor postion when left-clicking anywhere
    def get_event(self, event, data):
        if event == "mouse_left":
            position = BoardPosition.from_pixel(data)
            print(position, str(self.get_color_at_board_position(position)))


    """---------copied from miniworldmaker.boards.board.py-------------#
        This overwrites the *update* function of this board to make    #
        changing FPS possible.                                         #
                                                                       #
        If random bugs in the miniworldmaker occur, consider           #
        deactivating or recopying these lines from stated path of      #
        the miniworldmaker module.                                     #
    """                                                                #
    def update(self):                                                  #
        if self.is_running:                                            #
            self._tick = self._tick + 1                                #
            if self._tick > 101 - self.speed:                          #
                self._act_all()                                        #
                self._tick = 0                                         #
        self.frame = self.frame + 1                                    #
        for token in self.tokens:                                      #
            token.update()                                             #
        self.clock.tick(cnfg.fps) #<-- put desired amount of FPS here  #
#----------------------------------------------------------------------#

    






#----------------------------------------Objects----------------------------------------------------#
class stats():
    def __init__(self):

        self. forward_accerlation   = .1
        self.backward_accerlation   = .05
        self.breaking_power         = .2
        self. forward_friction      = .08
        self.backward_friction      = .02

        self. forward_max_speed     = 8
        self.backward_max_speed     = 1


class Player(Actor):

    def __init__(self, transformation, key_binding, texture_directory):
        super().__init__((transformation[0],transformation[1]))
        self.key_binding = key_binding
        self.stats = stats()

        self.add_image(path=texture_directory)
        self.costume.orientation = 0
        self.speed = 0
        self.turn_left(transformation[2])


    def act(self):
        # checks for collision
        if self.trace_line(self.speed*2, draw_line=True):
            self.stop()
        else:

            self.apply_friction()
            self.move(self.speed)

    def trace_line(self,distance,draw_line=False): # draws a line forward and checks if it intersects with a border
        if distance >= 0: # the length of the trace line has to be at least 2 pixel
            distance = max(2, distance)
        else:
            distance = min(-2,distance)
        x = self.position.x
        y = self.position.y

        x1 = math.cos(math.radians(self.direction - 90))*distance
        y1 = math.sin(math.radians(self.direction - 90))*distance
        line = Collision_Line((x,y),(x+x1,y+y1))
        if draw_line:
            line.draw(self.board._window.window_surface)
            pygame.display.update()

        nearest          = None
        nearest_distance = None
        for collision_line in self.board.collision_lines:
            intersection = line.get_intersection(collision_line)
            if intersection:
                distance = math.hypot(intersection.position[0]-x,intersection.position[1]-y)
                if distance != 0: # <-- keeps the player from getting stuck when the tracer is being used for collision detection
                    if nearest != None:
                        if distance < nearest_distance:
                            nearest          = intersection
                            nearest_distance = distance
                    else:
                        nearest         = intersection
                        nearest_distance = distance
        
        if nearest:
            return nearest
        else:
            return False

    def apply_friction(self):
        if self.speed > 0:
            self.speed = max(0,self.speed - self.stats.forward_friction)
        elif self.speed < 0:
            self.speed = min(0,self.speed + self.stats.backward_friction)

    def accelerate(self,direction):
        #*direction* can be "forward" or "backward"
        if direction == 'forward':
            self.speed =  min(self.stats. forward_max_speed,self.speed+self.stats. forward_accerlation)
        elif direction == 'backward' and self.speed <= 0:
            self.speed = -min(self.stats.backward_max_speed,-self.speed+self.stats.backward_accerlation)
        elif direction == 'backward' and self.speed >= 0:
            self.break_()

    def break_(self):
        if self.speed > 0:
            self.speed = max(0,self.speed-self.stats.breaking_power)
        elif self.speed < 0:
            self.speed = min(0,self.speed+self.stats.breaking_power)

    def stop(self):
        self.speed = 0


    def get_event(self, event, data):
        if event == "key_pressed" and self.key_binding:
            if self.key_binding.turn_left in data:
                self.turn_left(3)
            if self.key_binding.turn_right in data:
                self.turn_right(3)
            if self.key_binding.forward in data:
                self.accelerate('forward')
            if self.key_binding.backward in data:
                self.accelerate('backward')