#cd I:\IT\projects\Python\racing_PGA
#python collision_editor.py


import time, pygame,json
from lib.functions import *
        
collision_lines_updated = False
class Collision_Editor_Board(MyBoard):
    def __init__(self):
        super(MyBoard, self).__init__()
        self.buttons = []
        self.last_line_point = None


    def get_event(self, event, data):
        if event == "mouse_left":
            position = BoardPosition.from_pixel(data)
            position = (position.x,position.y)
            button   = self.is_pos_on_any_button(position)
            if button:
                if button.command:
                    if button.parameters:
                        if type(button.parameters) == 'tuple':
                            button.command(*button.parameters)
                        else:
                            button.command(button.parameters)
                    else:
                        button.command()
            else:
                if self.last_line_point:
                    self.collision_lines.append(Collision_Line(self.last_line_point,position))
                self.last_line_point = position
                self.update_collision_borders()
        elif event == 'mouse_right':
            if self.collision_lines:
                self.collision_lines[-1].remove(window_surface)
                self.collision_lines.pop()

    def act(self):
        global collision_lines_updated
        if not collision_lines_updated: # makes sure the collision lines are being updated when the first frame ticks
            board.update_collision_borders()
            collision_lines_updated = True

        # every frame this draws the buttons
        for button in self.buttons:
            button.draw(window_surface)

        pygame.display.update()

    def save_collision_lines(self,board):
        path = 'levels/'+str(cnfg.level_name)+'/collision_lines.txt'
        data = ''
        for line in self.collision_lines:
            data += str(line)+'\n'

        file = open(path, "w")
        file.write(data)
    def update_collision_borders(self):
        # creates a polygon without closing it (means without connecting last corner to first corner)
        for line in self.collision_lines:
            line.draw(window_surface)
        pygame.display.update()

    def is_pos_on_any_button(self,position):
        for button in self.buttons:
            if button.is_pos_on_button(position):
                return button
        else:
            return False



    def create_button(self,position,dimensions,text,font_size=16,command=None,parameters=None):
        button = Button(position,dimensions,text,font_size,command,parameters)
        self.buttons.append(button)

class Button():
    def __init__(self,position,dimensions,text,font_size,command,parameters):
        self.position       = position
        self.dimensions     = dimensions
        self.text           = text
        self.command        = command
        self.font_size      = font_size
        self.parameters     = parameters
        self.rect_object    = None
        self.text_object    = None

    def draw(self,surface):
        font = pygame.font.SysFont('Arial', self.font_size)
        text = font.render(self.text, True, (0,0,0))

        self.rect_obj = pygame.draw.rect(surface,(255,255,255),(self.position[0],self.position[1],self.dimensions[0],self.dimensions[1]))
        self.text_object = surface.blit(text, self.position)

    def is_pos_on_button(self,position):
        return self.position[0] <= position[0] and self.position[1] <= position[1] and self.position[0]+self.dimensions[0] >= position[0] and self.position[1]+self.dimensions[1] >= position[1]


board = Collision_Editor_Board()

window_surface = board._window.window_surface
board.load_level()
board.create_button((10,10) ,(120,20),'Save everything',command=board.save_collision_lines,parameters=(board))
#board.create_button((140,10),(60,20) ,'Border'         )
#board.create_button((210,10),(100,20),'Semipereable'   )

#line1 = Collision_Line((0,100),(10,0))
#line2 = Collision_Line((0,0),(10,100))
#print(line1.get_intersection(line2))

board.show()