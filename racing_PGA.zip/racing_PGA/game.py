#!/usr/bin/python3
#cd I:\IT\projects\Python\racing_PGA
#python game.py

import lib.functions as functions


board = functions.MyBoard()
board.load_level()
board.spawn_players()
board.show()
